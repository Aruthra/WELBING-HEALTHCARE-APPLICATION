# Welbing
An Android based application which uses Machine learning and IoT 
to predict the Disease and medicine for the Disease. 
The Accuracy of the Machine learning model is 95% as 
I collected my own dataset under the Guidance of Doctors.

Goto Readme pdf file for more information
