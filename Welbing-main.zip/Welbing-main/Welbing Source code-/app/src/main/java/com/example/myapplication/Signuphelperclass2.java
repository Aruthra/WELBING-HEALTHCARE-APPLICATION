package com.example.myapplication;

public class Signuphelperclass2 {
    String Address,pincode,landmark,phonenumber;
    String fullname,Emailid,DOB,Username,password;

    public Signuphelperclass2(String address, String pincode, String landmark, String phonenumber, String fullname, String emailid, String DOB, String username, String password) {
        Address = address;
        this.pincode = pincode;
        this.landmark = landmark;
        this.phonenumber = phonenumber;
        this.fullname = fullname;
        Emailid = emailid;
        this.DOB = DOB;
        Username = username;
        this.password = password;
    }

    public String getFullname() {
        return fullname;
    }

    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public String getEmailid() {
        return Emailid;
    }

    public void setEmailid(String emailid) {
        Emailid = emailid;
    }

    public String getDOB() {
        return DOB;
    }

    public void setDOB(String DOB) {
        this.DOB = DOB;
    }

    public String getUsername() {
        return Username;
    }

    public void setUsername(String username) {
        Username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getAddress() {
        return Address;
    }

    public void setAddress(String address) {
        Address = address;
    }

    public String getPincode() {
        return pincode;
    }

    public void setPincode(String pincode) {
        this.pincode = pincode;
    }

    public String getLandmark() {
        return landmark;
    }

    public void setLandmark(String landmark) {
        this.landmark = landmark;
    }

    public String getPhonenumber() {
        return phonenumber;
    }

    public void setPhonenumber(String phonenumber) {
        this.phonenumber = phonenumber;
    }
}
