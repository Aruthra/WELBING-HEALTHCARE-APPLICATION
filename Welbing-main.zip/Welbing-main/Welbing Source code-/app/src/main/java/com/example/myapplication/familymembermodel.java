package com.example.myapplication;

public class familymembermodel {
    private int memberprofile;
    private String name;
    private int onclick;
    private String icon;

    public String getIcon() {
        return icon;
    }

    public void setIcon(String icon) {
        this.icon = icon;
    }

    public int getOnclick() {
        return onclick;
    }

    public void setOnclick(int onclick) {
        this.onclick = onclick;
    }

    public int getMemberprofile() {
        return memberprofile;
    }

    public void setMemberprofile(int memberprofile) {
        this.memberprofile = memberprofile;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
